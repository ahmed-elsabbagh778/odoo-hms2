from . import patient
from . import dep
from  . import doctor
from . import  history_log
from . import  partner